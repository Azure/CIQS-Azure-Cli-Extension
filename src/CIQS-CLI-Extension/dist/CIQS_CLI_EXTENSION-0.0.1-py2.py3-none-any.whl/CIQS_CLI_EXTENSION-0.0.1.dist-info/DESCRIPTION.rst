An Azure CLI Extension for CIQS (Cloud Inteligence Quick Start).


